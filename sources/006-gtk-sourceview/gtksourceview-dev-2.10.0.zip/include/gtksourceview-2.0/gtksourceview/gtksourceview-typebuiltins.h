
/* Generated data (by glib-mkenums) */

#ifndef __GTKSOURCEVIEW_TYPEBUILTINS_H__
#define __GTKSOURCEVIEW_TYPEBUILTINS_H__ 1

#include <gtksourceview/gtksourceiter.h>
G_BEGIN_DECLS
#define GTK_TYPE_SOURCE_SEARCH_FLAGS gtk_source_search_flags_get_type()
GType gtk_source_search_flags_get_type (void);
G_END_DECLS

#include <gtksourceview/gtksourceview.h>
G_BEGIN_DECLS
#define GTK_TYPE_SOURCE_VIEW_GUTTER_POSITION gtk_source_view_gutter_position_get_type()
GType gtk_source_view_gutter_position_get_type (void);
G_END_DECLS

G_BEGIN_DECLS
#define GTK_TYPE_SOURCE_SMART_HOME_END_TYPE gtk_source_smart_home_end_type_get_type()
GType gtk_source_smart_home_end_type_get_type (void);
G_END_DECLS

G_BEGIN_DECLS
#define GTK_TYPE_SOURCE_DRAW_SPACES_FLAGS gtk_source_draw_spaces_flags_get_type()
GType gtk_source_draw_spaces_flags_get_type (void);
G_END_DECLS

#include <gtksourceview/gtksourcecompletion.h>
G_BEGIN_DECLS
#define GTK_TYPE_SOURCE_COMPLETION_ERROR gtk_source_completion_error_get_type()
GType gtk_source_completion_error_get_type (void);
G_END_DECLS

#include <gtksourceview/gtksourcecompletioncontext.h>
G_BEGIN_DECLS
#define GTK_TYPE_SOURCE_COMPLETION_ACTIVATION gtk_source_completion_activation_get_type()
GType gtk_source_completion_activation_get_type (void);
G_END_DECLS

#endif /* __GTKSOURCEVIEW_TYPEBUILTINS_H__ */

/* Generated data ends here */

